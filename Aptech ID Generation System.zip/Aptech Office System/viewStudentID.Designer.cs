﻿namespace Aptech_Office_System
{
    partial class viewStudentID
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(viewStudentID));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblShowID = new System.Windows.Forms.Label();
            this.lBoxStudentID = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblShowID);
            this.groupBox1.Controls.Add(this.lBoxStudentID);
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Location = new System.Drawing.Point(10, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(372, 326);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Student ID View";
            // 
            // lblShowID
            // 
            this.lblShowID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShowID.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShowID.ForeColor = System.Drawing.Color.Green;
            this.lblShowID.Location = new System.Drawing.Point(167, 146);
            this.lblShowID.Name = "lblShowID";
            this.lblShowID.Size = new System.Drawing.Size(205, 49);
            this.lblShowID.TabIndex = 1;
            this.lblShowID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lBoxStudentID
            // 
            this.lBoxStudentID.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lBoxStudentID.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lBoxStudentID.FormattingEnabled = true;
            this.lBoxStudentID.ItemHeight = 18;
            this.lBoxStudentID.Location = new System.Drawing.Point(3, 12);
            this.lBoxStudentID.Name = "lBoxStudentID";
            this.lBoxStudentID.ScrollAlwaysVisible = true;
            this.lBoxStudentID.Size = new System.Drawing.Size(165, 310);
            this.lBoxStudentID.TabIndex = 0;
            this.lBoxStudentID.SelectedIndexChanged += new System.EventHandler(this.lBoxStudentID_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label3.Font = new System.Drawing.Font("Bell MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(0, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(382, 24);
            this.label3.TabIndex = 9;
            this.label3.Text = "All Right Reserved - 2018 [Produced By Digital]";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // viewStudentID
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(382, 351);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "viewStudentID";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aptech ID Generation System: View Student ID";
            this.Load += new System.EventHandler(this.viewStudentID_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lBoxStudentID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblShowID;
    }
}