﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class viewIDStaff : Form
    {
        public viewIDStaff()
        {
            InitializeComponent();
        }

        private void viewIDStaff_Load(object sender, EventArgs e)
        {
            this.viewStaffID();

        }
        private void viewStaffID()
        {
            string View;
            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT [FIRST_NAME],[LAST_NAME],[UNIQUE_ID],[STAFF_UNIQUE_ID] FROM tbl_StaffID_Info ORDER BY UNIQUE_ID DESC", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            View = dr["LAST_NAME"].ToString() + " " + dr["FIRST_NAME"].ToString() + " -:::::- " + dr["STAFF_UNIQUE_ID"].ToString();
                            List<String> StaffIDList = new List<string>();
                            StaffIDList.Add(View);

                            foreach (string Reminder in StaffIDList)
                            {
                                lBoxStaffID.Items.Add(Reminder);
                                lBoxStaffID.Refresh();
                            }
                        }
                        con.Close();
                    }
                }
            }
        }
    }
}
