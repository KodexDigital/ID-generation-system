﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aptech_Office_System
{
    public partial class startScreen : Form
    {
        int ms, s, m, h;
        //int second;
        int i = 0;
        public startScreen()
        {
            InitializeComponent();
            this.timer_Start.Enabled = true;
            //timer_Start.Interval = 5000;
            //timer_Start.Start();

            pBar.Minimum = 0;
            pBar.Maximum = 13;

            //for (i = 0; i <= 100; i++)
            //{
            //    pBar.Value = i;
            //}

                // pBar.Value = pBar.Value + 1;

                ms = 0;
     
        }

        private void timer_Start_Tick(object sender, EventArgs e)
        {
            ms = ms + 1;
            if (ms == 9)
            {
                ms = 0;
                s = s + 1;
               // lblSecond.Text = s.ToString();
                //lblBye.Text = s.ToString();
                if (s == 59)
                {
                    s = 0;
                    m = m + 1;
                    //lblMin.Text = m.ToString();
                    if (m == 59)
                    {
                        m = 0;
                        h = h + 1;
                       // lblHour.Text = h.ToString();
                    }
                }

                //lblBye.Text = s.ToString() + ":" + ms.ToString();
            }

            pBar.Value = s;
            
            if (s == 2)
            {
                lblTimer.Text = "Hello, Admin., Toady is " + System.DateTime.Today.ToShortDateString() + ". Hope You Will Enjoy Using This System?";
            }
            else if (s == 8)
            {
                lblTimer.Text = "Stay Tight And Make The Best Moment Of It...";
                lblBye.Text = "Good Luck!!!";
            }
            else if (s == 13)
            {
                loginUser NewLogin = new loginUser();
                NewLogin.Show();
                this.Hide();

                timer_Start.Enabled = false;
                timer_Start.Stop();
            }

           
        }
    }
}
