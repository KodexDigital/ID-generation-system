﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class viewStudentID : Form
    {
        public viewStudentID()
        {
            InitializeComponent();
        }

        private void viewStudentID_Load(object sender, EventArgs e)
        {
            this.IDStudent_View();
        }

        private void IDStudent_View()
        {
            string View;
            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT [FULL_NAME],[UNIQUE_ID] FROM tbl_StudentID_Info ORDER BY UNIQUE_ID DESC", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            View = dr["FULL_NAME"].ToString().ToString();
                            List<String> StudentIDList = new List<string>();
                            StudentIDList.Add(View);

                            foreach (string Reminder in StudentIDList)
                            {
                                lBoxStudentID.Items.Add(Reminder);
                                lBoxStudentID.Refresh();
                            }
                        }
                        con.Close();
                    }
                }
            }
        }
 
        private void viewID()
        {
           // string View;
            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT [FULL_NAME],[STUDENT_UNIQUE_ID] FROM tbl_StudentID_Info WHERE FULL_NAME ='" + lBoxStudentID.SelectedItem.ToString() + "' ", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            lblShowID.Text = dr["STUDENT_UNIQUE_ID"].ToString();
                        }
                        con.Close();
                    }
                }
            }
        }

        private void lBoxStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lBoxStudentID.SelectedItem == null)
            {
                MessageBox.Show("Nothing is selected yet!","Information");
            }
            else
            { 
            this.viewID();
            }
        }
    }
}
