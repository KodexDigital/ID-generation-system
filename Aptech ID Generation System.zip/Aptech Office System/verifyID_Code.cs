﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class verifyID_Code : Form
    {
        public verifyID_Code()
        {
            InitializeComponent();
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
           // string getID;
            if (this.txtStudentID.Text == "")
            { this.lblErrCode.Text = "*Required: Student's ID"; }
            else 
            {
                //select the records from the recieval table here
                {
                    string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(constring))
                    {
                        using (SqlCommand cmd = new SqlCommand("SELECT [FULL_NAME],[CATEGOREY],[DOA],[STUDENT_UNIQUE_ID] FROM tbl_StudentID_Info WHERE STUDENT_UNIQUE_ID ='" + txtStudentID.Text.ToString() + "' ", con))
                        {
                            cmd.CommandType = CommandType.Text;
                            con.Open();
                            SqlDataReader dr = cmd.ExecuteReader();
                            if (dr.HasRows == true)
                            {
                                dr.Read();
                                this.txtName.Text = dr["FULL_NAME"].ToString();
                                this.txtDOA.Text = dr["DOA"].ToString();
                                this.txtCate.Text = dr["CATEGOREY"].ToString();

                                this.btnContinue.Enabled = true;
                                this.lblErrCode.Text = "";
                            }
                            else
                            {
                                MessageBox.Show("The Supplied Student's ID: " + txtStudentID.Text.ToString() + " Does Not Exist In Our Database" + "\r\n" + "Please Check The ID And Try Again!" + "\r\n" + "Thank You!!", "Verifying...");
                                this.txtName.Text = "waiting...";
                                this.txtDOA.Text = "waiting...";
                                this.txtCate.Text = "waiting...";

                                this.lblErrCode.Text = "";

                                //lblConnect.Visible = true;
                                //lblConnect.Text = "Access Rejected - Something is Missing...";
                            }


                            con.Close();
                        }
                    }
                }
            }
           
        }

        private void txtStudentID_TextChanged(object sender, System.EventArgs e)
        {
            if (this.txtStudentID.Text != "")
            {
                this.lblErrCode.Text = ""; 
            }
        }

        private void btnContinue_Click(object sender, System.EventArgs e)
        {
            //studentBatchCode NewStudentBatchCode = new studentBatchCode(txtStudentID.Text);
            //NewStudentBatchCode.IDStudent_Get = this.txtStudentID.Text.ToString();
            //NewStudentBatchCode.Show();
            //this.Hide();
        }
    }
}
