﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class StudentCatAdd : Form
    {
        private string Category, Description, dateCreated;
        public StudentCatAdd()
        {
            InitializeComponent();
        }

        private void StudentCatAdd_Load(object sender, EventArgs e)
        {
            this.txtCategory.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Category = this.txtCategory.Text.ToUpper();
            Description = this.txtDescription.Text.ToString();
            dateCreated = System.DateTime.Now.ToShortDateString();

            if (txtCategory.Text == "") { this.lblErrCate.Text = "Category Please!"; txtCategory.Focus(); }
            else if (txtDescription.Text == "") { this.lblErrDescript.Text = "Description Please!"; txtDescription.Focus(); }
            else
            {
            {

                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_CourseCategory (CATEGORY, DESCRIPTION, createdDate) VALUES (@CATEGORY, @DESCRIPTION, @createdDate)", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@CATEGORY", Category.Trim());
                        cmd.Parameters.AddWithValue("@DESCRIPTION", Description.Trim());
                        cmd.Parameters.AddWithValue("@createdDate", dateCreated.Trim());
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        MessageBox.Show("NEW COURSE CATEGORY SAVED SUCCESSFULLY!", "New Category...");
                        this.txtCategory.Clear();
                        this.txtDescription.Clear();
                        this.lblErrCate.Text = "";
                        this.lblErrDescript.Text = "";
                        con.Close();

                    }
                }
            }
            }
        }

        private void txtCategory_TextChanged(object sender, EventArgs e)
        {
            if (this.txtCategory.Text != "") { this.lblErrCate.Text = ""; }
        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {
            if (this.txtDescription.Text != "") { this.lblErrDescript.Text = ""; }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.txtCategory.Clear();
            this.txtDescription.Clear();
            this.lblErrCate.Text = "";
            this.lblErrDescript.Text = "";
            this.txtCategory.Focus();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
