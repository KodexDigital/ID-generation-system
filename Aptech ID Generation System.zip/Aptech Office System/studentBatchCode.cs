﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class studentBatchCode : Form
    {
        public string classTime_student;
        private int uniqueNo, cntID, newID;
        string batchName_BC, batchCode_BC; 
        string batchName_CD, batchCode_CD;
        string batchName_DE, batchCode_DE;
        string batchName_EF, batchCode_EF;

        string uniqueValue_BC;
        string uniqueValue_CD;
        string uniqueValue_DE;
        string uniqueValue_EF;


       public studentBatchCode()
        {
            InitializeComponent();
            cntID = 1;
            newID = 0;

            //this.IDStudent_Get = Student_ID;
        }

        //Validating and Checking Class BC Right Here!
        public void validateID_Class_BC()
        {
                  string getID_BC;
                  string firstID_BC;
             //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT MAX (uniqueCode) AS max_UniqueCode_BC FROM tbl_student_BatchCode WHERE classTime ='" + classTime_student.ToString() + "' ", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == true)
                        {
                            dr.Read();
                            getID_BC = dr["max_UniqueCode_BC"].ToString();

                            if (getID_BC == string.Empty)
                            {
                                firstID_BC = "null";
                                if (firstID_BC == "null")  // this section is to check if ID exist for the first time
                                {
                                    //newID += cntID;
                                    //this.generateStaffID_NewEmpty();
                                    // MessageBox.Show(newID.ToString("000"));
                                    newID += cntID;
                                    uniqueValue_BC = newID.ToString("000");
                                    batchCode_BC = batchName_BC + uniqueValue_BC;
                                    lblShowCode.Text = batchCode_BC.ToString();
                                    //MessageBox.Show(batchCode);

                                }
                            }
                            else if (getID_BC != string.Empty)  //Here is for the generation and insertion  this section is to check if ID always
                            {
                                firstID_BC = getID_BC.ToString();
                                uniqueNo = int.Parse(firstID_BC) + cntID;
                                uniqueValue_BC = uniqueNo.ToString("000");
                                batchCode_BC = batchName_BC + uniqueValue_BC;
                                lblShowCode.Text = batchCode_BC.ToString();
                               // MessageBox.Show(batchCode);
                            }
                        }
                        else
                        {
                            //MessageBox.Show("NO ID Yet!");
                            //lblConnect.Visible = true;
                            //lblConnect.Text = "Access Rejected - Something is Missing...";
                        }


                        con.Close();
                    }
                }
            }
        }
        
        //Validating and Checking Class CD Right Here!
        public void validateID_Class_CD()
        {
            string getID_CD;
            string firstID_CD;
            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT MAX (uniqueCode) AS max_UniqueCode_CD FROM tbl_student_BatchCode WHERE classTime ='" + classTime_student.ToString() + "'", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == true)
                        {
                            dr.Read();
                            getID_CD = dr["max_UniqueCode_CD"].ToString();

                            if (getID_CD == string.Empty)
                            {
                                firstID_CD = "null";
                                if (firstID_CD == "null")  // this section is to check if ID exist for the first time
                                {
                                    //newID += cntID;
                                    //this.generateStaffID_NewEmpty();
                                    // MessageBox.Show(newID.ToString("000"));
                                    newID += cntID;
                                    uniqueValue_CD = newID.ToString("000");
                                    batchCode_CD = batchName_CD + uniqueValue_CD;
                                    lblShowCode.Text = batchCode_CD.ToString();
                                    //MessageBox.Show(batchCode);

                                }
                            }
                            else if (getID_CD != string.Empty)  //Here is for the generation and insertion  this section is to check if ID always
                            {
                                firstID_CD = getID_CD.ToString();
                                uniqueNo = int.Parse(firstID_CD) + cntID;
                                uniqueValue_CD = uniqueNo.ToString("000");
                                batchCode_CD = batchName_CD + uniqueValue_CD;
                                lblShowCode.Text = batchCode_CD.ToString();
                                // MessageBox.Show(batchCode);
                            }
                        }
                        else
                        {
                            //MessageBox.Show("NO ID Yet!");
                            //lblConnect.Visible = true;
                            //lblConnect.Text = "Access Rejected - Something is Missing...";
                        }


                        con.Close();
                    }
                }
            }
        }

        //Validating and Checking Class DE Right Here!
        public void validateID_Class_DE()
        {
            string getID_DE;
            string firstID_DE;
            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT MAX (uniqueCode) AS max_UniqueCode_DE FROM tbl_student_BatchCode WHERE classTime ='" + classTime_student.ToString() + "'", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == true)
                        {
                            dr.Read();
                            getID_DE = dr["max_UniqueCode_DE"].ToString();

                            if (getID_DE == string.Empty)
                            {
                                firstID_DE = "null";
                                if (firstID_DE == "null")  // this section is to check if ID exist for the first time
                                {
                                    //newID += cntID;
                                    //this.generateStaffID_NewEmpty();
                                    // MessageBox.Show(newID.ToString("000"));
                                    newID += cntID;
                                    uniqueValue_DE = newID.ToString("000");
                                    batchCode_DE = batchName_DE + uniqueValue_DE;
                                    lblShowCode.Text = batchCode_DE.ToString();
                                    //MessageBox.Show(batchCode);

                                }
                            }
                            else if (getID_DE != string.Empty)  //Here is for the generation and insertion  this section is to check if ID always
                            {
                                firstID_DE = getID_DE.ToString();
                                uniqueNo = int.Parse(firstID_DE) + cntID;
                                uniqueValue_DE = uniqueNo.ToString("000");
                                batchCode_DE = batchName_DE + uniqueValue_DE;
                                lblShowCode.Text = batchCode_DE.ToString();
                                // MessageBox.Show(batchCode);
                            }
                        }
                        else
                        {
                            //MessageBox.Show("NO ID Yet!");
                            //lblConnect.Visible = true;
                            //lblConnect.Text = "Access Rejected - Something is Missing...";
                        }


                        con.Close();
                    }
                }
            }
        }

        //Validating and Checking Class EF Right Here!
        public void validateID_Class_EF()
        {
            string getID_EF;
            string firstID_EF;
            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT MAX (uniqueCode) AS max_UniqueCode_EF FROM tbl_student_BatchCode WHERE classTime ='" + classTime_student.ToString() + "'", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == true)
                        {
                            dr.Read();
                            getID_EF = dr["max_UniqueCode_EF"].ToString();

                            if (getID_EF == string.Empty)
                            {
                                firstID_EF = "null";
                                if (firstID_EF == "null")  // this section is to check if ID exist for the first time
                                {
                                    //newID += cntID;
                                    //this.generateStaffID_NewEmpty();
                                    // MessageBox.Show(newID.ToString("000"));
                                    newID += cntID;
                                    uniqueValue_EF = newID.ToString("000");
                                    batchCode_EF = batchName_EF + uniqueValue_EF;
                                    lblShowCode.Text = batchCode_EF.ToString();
                                    //MessageBox.Show(batchCode);

                                }
                            }
                            else if (getID_EF != string.Empty)  //Here is for the generation and insertion  this section is to check if ID always
                            {
                                firstID_EF = getID_EF.ToString();
                                uniqueNo = int.Parse(firstID_EF) + cntID;
                                uniqueValue_EF = uniqueNo.ToString("000");
                                batchCode_EF = batchName_EF + uniqueValue_EF;
                                lblShowCode.Text = batchCode_EF.ToString();
                                // MessageBox.Show(batchCode);
                            }
                        }
                        else
                        {
                            //MessageBox.Show("NO ID Yet!");
                            //lblConnect.Visible = true;
                            //lblConnect.Text = "Access Rejected - Something is Missing...";
                        }


                        con.Close();
                    }
                }
            }
        }

        private void studentBatchCode_Load(object sender, EventArgs e)
        {
           // this.txtStudentID.Text = IDStudent_Get;
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            // string getID;
            if (this.txtStudentID_Verify.Text == "")
            { this.lblErrCode_Verify.Text = "*Required: Student's ID"; }
            else
            {
                //select the records from the recieval table here
                {
                    string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(constring))
                    {
                        using (SqlCommand cmd = new SqlCommand("SELECT [FULL_NAME],[CATEGOREY],[DOA],[STUDENT_UNIQUE_ID] FROM tbl_StudentID_Info WHERE STUDENT_UNIQUE_ID ='" + txtStudentID_Verify.Text.ToString() + "' ", con))
                        {
                            cmd.CommandType = CommandType.Text;
                            con.Open();
                            SqlDataReader dr = cmd.ExecuteReader();
                            if (dr.HasRows == true)
                            {
                                dr.Read();
                                this.txtName.Text = dr["FULL_NAME"].ToString();
                                this.txtDOA.Text = dr["DOA"].ToString();
                                this.txtCate.Text = dr["CATEGOREY"].ToString();

                                this.btnContinue.Enabled = true;
                                this.lblErrCode_Verify.Text = "";

                                int i;
                                pBarVerify.Minimum = 0;
                                pBarVerify.Maximum = 50;

                                for (i = 0; i <= 50; i++)
                                {
                                    pBarVerify.Value = i;
                                }

                               this.pBarVerify.Visible = true;
                            }
                            else
                            {
                                MessageBox.Show("The Supplied Student's ID: " + txtStudentID_Verify.Text.ToString() + " Does Not Exist In Our Database" + "\r\n" + "Please Check The ID And Try Again!" + "\r\n" + "Thank You!!", "Verifying...");
                                this.txtName.Text = "waiting...";
                                this.txtDOA.Text = "waiting...";
                                this.txtCate.Text = "waiting...";

                                this.lblErrCode_Verify.Text = "";

                                this.pBarVerify.Visible = false;

                                //lblConnect.Visible = true;
                                //lblConnect.Text = "Access Rejected - Something is Missing...";
                            }


                            con.Close();
                        }
                    }
                }
            }
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            this.txtStudentID.Text = this.txtStudentID_Verify.Text.ToString();
            this.gBoxCode.Enabled = true;
            this.gBoxVerify.Enabled = false;
            this.gBoxGetInfo.Enabled = false;


            this.pBarVerify.Visible = false;
        }

        private void txtStudentID_Verify_TextChanged(object sender, EventArgs e)
        {
            if (this.txtStudentID_Verify.Text != "")
            {
                this.lblErrCode_Verify.Text = "";
            }
        }

        private void btnNew_Click_1(object sender, EventArgs e)
        {
            this.txtStudentID.Clear();
            this.gBoxCode.Enabled = false;
            this.gBoxVerify.Enabled = true;
            this.gBoxGetInfo.Enabled = true;
            this.txtStudentID_Verify.Focus();

            this.txtStudentID_Verify.Clear();
            this.txtName.Clear();
            this.txtDOA.Clear();
            this.txtCate.Clear();


            this.txtStudentID.Clear();
            this.pixError.Visible = false;
            this.chk_9.Checked = false;
            this.chk_9.Enabled = true;
            this.chk_11.Checked = false;
            this.chk_11.Enabled = true;
            this.chk_2.Checked = false;
            this.chk_2.Enabled = true;
            this.chk_4.Checked = false;
            this.chk_4.Enabled = true;
            this.lblShowCode.Text = "";

            cntID = 1;
            newID = 0;


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (this.chk_9.Checked == true && chk_11.Checked == false && chk_2.Checked == false && chk_4.Checked == false)
            {
                {this.SaveBatchCodes_BC();}             
            }
            else if (chk_11.Checked == true && chk_9.Checked == false && chk_2.Checked == false && chk_4.Checked == false) 
            {
                this.SaveBatchCodes_CD();
            }
            else if (chk_2.Checked == true && chk_9.Checked == false && chk_11.Checked == false && chk_4.Checked == false) 
            { 
                this.SaveBatchCodes_DE(); 
            }
            else if (chk_4.Checked == true && chk_9.Checked == false && chk_11.Checked == false && chk_2.Checked == false) 
            {
                this.SaveBatchCodes_EF(); 
            }
            else
            {
                this.pixError.Visible = true;
                this.lblShowCode.Text = "No Time Selected";
                this.lblShowCode.ForeColor = Color.Red;

            }
        }

        public void SaveBatchCodes_CD()
        {
            string sID, createdDate;

            sID = this.txtStudentID.Text.ToString();
            createdDate = DateTime.Today.ToShortDateString();
            string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_student_BatchCode (studentID, classTime, batchCode, uniqueCode, createdDate) VALUES (@studentID, @classTime, @batchCode, @uniqueCode, @createdDate)", con))
                {
                    //cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@studentID", sID.Trim());
                    cmd.Parameters.AddWithValue("@classTime", classTime_student.Trim());
                    cmd.Parameters.AddWithValue("@batchCode", batchCode_CD.Trim());
                    cmd.Parameters.AddWithValue("@uniqueCode", uniqueValue_CD.Trim());
                    cmd.Parameters.AddWithValue("@createdDate", createdDate.Trim());
                    //cmd.Parameters.AddWithValue("@UNIQUE_ID", uniqueValue.Trim());
                    //cmd.Parameters.AddWithValue("@STUDENT_UNIQUE_ID", staffUniqueID.Trim());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show("STUDENT'S BATCH CODE SAVED SUCCESSFULLY!");
                    this.pixError.Visible = false;
                    this.lblShowCode.Text = "";
                    con.Close();

                }
            }
        }
        public void SaveBatchCodes_BC()
        {
            string sID, createdDate;

            sID = this.txtStudentID.Text.ToString();
            createdDate = DateTime.Today.ToShortDateString();
            string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_student_BatchCode (studentID, classTime, batchCode, uniqueCode, createdDate) VALUES (@studentID, @classTime, @batchCode, @uniqueCode, @createdDate)", con))
                {
                    //cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@studentID", sID.Trim());
                    cmd.Parameters.AddWithValue("@classTime", classTime_student.Trim());
                    cmd.Parameters.AddWithValue("@batchCode", batchCode_BC.Trim());
                    cmd.Parameters.AddWithValue("@uniqueCode", uniqueValue_BC.Trim());
                    cmd.Parameters.AddWithValue("@createdDate", createdDate.Trim());
                    //cmd.Parameters.AddWithValue("@UNIQUE_ID", uniqueValue.Trim());
                    //cmd.Parameters.AddWithValue("@STUDENT_UNIQUE_ID", staffUniqueID.Trim());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show("STUDENT'S BATCH CODE SAVED SUCCESSFULLY!");
                    this.pixError.Visible = false;
                    this.lblShowCode.Text = "";
                    con.Close();

                }
            }
        }
        public void SaveBatchCodes_DE()
        {
            string sID, createdDate;

            sID = this.txtStudentID.Text.ToString();
            createdDate = DateTime.Today.ToShortDateString();
            string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_student_BatchCode (studentID, classTime, batchCode, uniqueCode, createdDate) VALUES (@studentID, @classTime, @batchCode, @uniqueCode, @createdDate)", con))
                {
                    //cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@studentID", sID.Trim());
                    cmd.Parameters.AddWithValue("@classTime", classTime_student.Trim());
                    cmd.Parameters.AddWithValue("@batchCode", batchCode_DE.Trim());
                    cmd.Parameters.AddWithValue("@uniqueCode", uniqueValue_DE.Trim());
                    cmd.Parameters.AddWithValue("@createdDate", createdDate.Trim());
                    //cmd.Parameters.AddWithValue("@UNIQUE_ID", uniqueValue.Trim());
                    //cmd.Parameters.AddWithValue("@STUDENT_UNIQUE_ID", staffUniqueID.Trim());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show("STUDENT'S BATCH CODE SAVED SUCCESSFULLY!");
                    this.pixError.Visible = false;
                    this.lblShowCode.Text = "";
                    con.Close();

                }
            }
        }
        public void SaveBatchCodes_EF()
        {
            string sID, createdDate;

            sID = this.txtStudentID.Text.ToString();
            createdDate = DateTime.Today.ToShortDateString();
            string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_student_BatchCode (studentID, classTime, batchCode, uniqueCode, createdDate) VALUES (@studentID, @classTime, @batchCode, @uniqueCode, @createdDate)", con))
                {
                    //cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@studentID", sID.Trim());
                    cmd.Parameters.AddWithValue("@classTime", classTime_student.Trim());
                    cmd.Parameters.AddWithValue("@batchCode", batchCode_EF.Trim());
                    cmd.Parameters.AddWithValue("@uniqueCode", uniqueValue_EF.Trim());
                    cmd.Parameters.AddWithValue("@createdDate", createdDate.Trim());
                    //cmd.Parameters.AddWithValue("@UNIQUE_ID", uniqueValue.Trim());
                    //cmd.Parameters.AddWithValue("@STUDENT_UNIQUE_ID", staffUniqueID.Trim());
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show("STUDENT'S BATCH CODE SAVED SUCCESSFULLY!");
                    this.pixError.Visible = false;
                    this.lblShowCode.Text = "";
                    con.Close();

                }
            }
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {
            ToolTip buttonToolTip = new ToolTip();
            buttonToolTip.ToolTipTitle = "Verify Notice!";
            buttonToolTip.UseFading = true;
            buttonToolTip.UseAnimation = true;
            buttonToolTip.IsBalloon = true;
            buttonToolTip.ShowAlways = true;
            buttonToolTip.AutoPopDelay = 5000;
            buttonToolTip.InitialDelay = 1000;
            buttonToolTip.ReshowDelay = 500;
            buttonToolTip.SetToolTip(btnVerify, "Click me to execute.");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Home newHome = new Home();
            newHome.Show();
            this.Hide();
        }

        //Class BC
        private void chk_9_CheckedChanged_1(object sender, EventArgs e)
        {
            bool checkedTime = true;
            if (checkedTime == true && chk_9.Checked == true)
            {
                classTime_student = chk_9.Text;
                batchName_BC = "BC - ";

                chk_11.Checked = false;
                chk_11.Enabled = false;

                chk_2.Checked = false;
                chk_2.Enabled = false;

                chk_4.Checked = false;
                chk_4.Enabled = false;


                this.validateID_Class_BC();

                this.pixError.Visible = false;
                this.lblShowCode.ForeColor = System.Drawing.Color.Green;

                //Testing
                //MessageBox.Show(classTime_student);

            }
            else if (checkedTime == true && chk_9.Checked == false)
            {
                classTime_student = "";
                batchName_BC = "";

                chk_11.Checked = false;
                chk_11.Enabled = true;

                chk_2.Checked = false;
                chk_2.Enabled = true;

                chk_4.Checked = false;
                chk_4.Enabled = true;

                lblShowCode.Text = "";

            }
        }


        //Class CD
        private void chk_11_CheckedChanged_1(object sender, EventArgs e)
        {
            bool checkedTime = true;
            if (checkedTime == true && chk_11.Checked == true)
            {
                classTime_student = chk_11.Text;
                batchName_CD = "CD - ";

                chk_9.Checked = false;
                chk_9.Enabled = false;

                chk_2.Checked = false;
                chk_2.Enabled = false;

                chk_4.Checked = false;
                chk_4.Enabled = false;

                this.validateID_Class_CD();

                this.pixError.Visible = false;
                this.lblShowCode.ForeColor = System.Drawing.Color.Green;

                //Testing
                // MessageBox.Show(classTime_student);
            }
            else if (checkedTime == true && chk_11.Checked == false)
            {
                classTime_student = "";
                batchName_CD = "";

                chk_9.Checked = false;
                chk_9.Enabled = true;

                chk_2.Checked = false;
                chk_2.Enabled = true;

                chk_4.Checked = false;
                chk_4.Enabled = true;

                lblShowCode.Text = "";

            }
        }

        //Class DE
        private void chk_2_CheckedChanged_1(object sender, EventArgs e)
        {
            bool checkedTime = true;
            if (checkedTime == true && chk_2.Checked == true)
            {
                classTime_student = chk_2.Text;
                batchName_DE = "DE - ";

                chk_11.Checked = false;
                chk_11.Enabled = false;

                chk_9.Checked = false;
                chk_9.Enabled = false;

                chk_4.Checked = false;
                chk_4.Enabled = false;

                this.validateID_Class_DE();

                this.pixError.Visible = false;
                this.lblShowCode.ForeColor = System.Drawing.Color.Green;

                //Testing
                //MessageBox.Show(classTime_student);

            }
            else if (checkedTime == true && chk_2.Checked == false)
            {
                classTime_student = "";
                batchName_DE = "";

                chk_11.Checked = false;
                chk_11.Enabled = true;

                chk_9.Checked = false;
                chk_9.Enabled = true;

                chk_4.Checked = false;
                chk_4.Enabled = true;

                lblShowCode.Text = "";

            }
        }

        //Class EF
        private void chk_4_CheckedChanged(object sender, EventArgs e)
        {
            bool checkedTime = true;
            if (checkedTime == true && chk_4.Checked == true)
            {
                classTime_student = chk_4.Text;
                batchName_EF = "EF - ";

                chk_11.Checked = false;
                chk_11.Enabled = false;

                chk_2.Checked = false;
                chk_2.Enabled = false;

                chk_9.Checked = false;
                chk_9.Enabled = false;

                this.validateID_Class_EF();

                this.pixError.Visible = false;
                this.lblShowCode.ForeColor = System.Drawing.Color.Green;

                //Testing
                //MessageBox.Show(classTime_student);

            }
            else if (checkedTime == true && chk_4.Checked == false)
            {
                classTime_student = "";
                batchName_EF = "";

                chk_11.Checked = false;
                chk_11.Enabled = true;

                chk_2.Checked = false;
                chk_2.Enabled = true;

                chk_9.Checked = false;
                chk_9.Enabled = true;

                lblShowCode.Text = "";

            }
        }

    }
}
