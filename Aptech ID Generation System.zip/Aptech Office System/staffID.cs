﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class staffID : Form
    {
        private string firstName, middleName, lastName;
        private string dateOfAppointmane, staffUniqueID;
        private string userOn, dateOfCreation;

        private string company, uniqueValue, firstID;
        private int uniqueNo, cntID, newID;
        private string getID;


        public staffID()
        {
            InitializeComponent();
            cntID = 1;
            newID = 0;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.Save_ID();

        }
        private void validateID()
        {

            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT MAX (UNIQUE_ID) AS max_UniqueID FROM tbl_StaffID_Info", con))
                        //("SELECT TOP (1) [UNIQUE_ID] FROM tbl_StaffID_Info WHERE UNIQUE_ID = 0 OR Status = 1 ORDER BY UNIQUE_ID DESC'", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == true)
                        {
                            dr.Read();
                            getID = dr["max_UniqueID"].ToString();

                            if (getID == string.Empty)
                            {
                                firstID = "null";
                                if (firstID == "null")  // this section is to check if ID exist for the first time
                                {
                                    //newID += cntID;
                                   this.generateStaffID_NewEmpty();
                                    // MessageBox.Show(newID.ToString("000"));

                                }
                            }
                            else if (getID != string.Empty)  //Here is for the generation and insertion  this section is to check if ID always
                            {
                                //firstID = getID.ToString();
                                //uniqueNo = int.Parse(firstID) + cntID;
                                this.generateStaffID_Existing();
                                //MessageBox.Show(uniqueNo.ToString("000"));
                            }
                        }
                        else
                        {
                            //MessageBox.Show("NO ID Yet!");
                            //lblConnect.Visible = true;
                            //lblConnect.Text = "Access Rejected - Something is Missing...";
                        }


                        con.Close();
                    }
                }
            }
        }
        public void generateStaffID_NewEmpty()
        {
            if (cboxDay.Text == "Select Day" || cboxMonth.Text == "Select Month" || cboxYear.Text == "Select Year")
            { MessageBox.Show("Appointment Date Not Properly Selected!" + "\r\n" + "Please Correct This Then Continue... " + " Thank You!", "Validate ID..."); }
            else
            {
                company = "apt".ToUpper();
                dateOfAppointmane = this.cboxDay.SelectedItem.ToString() + this.cboxMonth.SelectedItem.ToString() + cboxYear.SelectedItem.ToString();
                //uniqueNo = 1;
                newID += cntID;
                uniqueValue = newID.ToString("000");
                staffUniqueID = company + dateOfAppointmane + uniqueValue;
                MessageBox.Show("STAFF UNIQUE ID GENERATED SUCCESSFULLY!" + "\r\n" + "Please Copy It Out, Then Save it by clicking the 'Save Button'", "ID Generate...");
                lblShowID.Text = staffUniqueID.ToString();

                this.btnSave.Enabled = true;
            }
            //else 
        }
        public void generateStaffID_Existing()
        {
            if (cboxDay.Text == "Select Day" || cboxMonth.Text == "Select Month" || cboxYear.Text == "Select Year")
                { MessageBox.Show("Appointment Date Not Properly Selected!" + "\r\n" + "Please Correct This Then Continue... " + " Thank You!", "Validate ID..."); }
            else
            {
            company = "apt".ToUpper();
            dateOfAppointmane = this.cboxDay.SelectedItem.ToString() + this.cboxMonth.SelectedItem.ToString() + cboxYear.SelectedItem.ToString();
            //uniqueNo = 1;
            firstID = getID.ToString();
            uniqueNo = int.Parse(firstID) + cntID;
            uniqueValue = uniqueNo.ToString("000");
            staffUniqueID = company + dateOfAppointmane + uniqueValue;
            MessageBox.Show("STAFF UNIQUE ID GENERATED SUCCESSFULLY!" + "\r\n" + "Please Copy It Out, Then Save it by clicking the 'Save Button'","ID Generate...");
            lblShowID.Text = staffUniqueID.ToString();

            this.btnSave.Enabled = true;
            }
            //else 
        }
        private void Save_ID()
        {
            if (this.txtFN.Text == string.Empty) { MessageBox.Show("Required: First Name" + "\r\n" + "Please Enter The Staff's First Name", "Required Field..."); this.txtFN.Focus(); }
            else if (this.txtLN.Text == string.Empty) { MessageBox.Show("Required: Last Name" + "\r\n" + "Please Enter The Staff's Last Name", "Required Field..."); this.txtLN.Focus(); }
            else
            {
                firstName = this.txtFN.Text.ToString();
                middleName = this.txtMN.Text.ToString();
                lastName = this.txtLN.Text.ToString();
                dateOfCreation = System.DateTime.Now.ToShortDateString();
                userOn = "";

                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_StaffID_Info (FIRST_NAME, MIDDLE_NAME, LAST_NAME, DOA, CreatedBy, CreadetDate, UNIQUE_ID, STAFF_UNIQUE_ID) VALUES (@FIRST_NAME, @MIDDLE_NAME, @LAST_NAME, @DOA, @CreatedBy, @CreadetDate, @UNIQUE_ID, @STAFF_UNIQUE_ID)", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@FIRST_NAME", firstName.Trim());
                        cmd.Parameters.AddWithValue("@MIDDLE_NAME", middleName.Trim());
                        cmd.Parameters.AddWithValue("@LAST_NAME", lastName.Trim());
                        cmd.Parameters.AddWithValue("@DOA", dateOfAppointmane.Trim());
                        cmd.Parameters.AddWithValue("@CreatedBy", userOn.Trim());
                        cmd.Parameters.AddWithValue("@CreadetDate", dateOfCreation.Trim());
                        cmd.Parameters.AddWithValue("@UNIQUE_ID", uniqueValue.Trim());
                        cmd.Parameters.AddWithValue("@STAFF_UNIQUE_ID", staffUniqueID.Trim());
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        MessageBox.Show("STAFF UNIQUE ID SAVED SUCCESSFULLY!");
                        this.txtFN.Clear();
                        this.txtMN.Clear();
                        this.txtLN.Clear();
                        this.cboxDay.Text = "Select Day".ToString();
                        this.cboxMonth.Text = "Select Month".ToString();
                        this.cboxYear.Text = "Select Year".ToString();
                        this.lblShowID.Text = string.Empty;
                        con.Close();

                    }
                }
            }
           

        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            bool buttonClicked = true;
            if (buttonClicked == true) 
            {
                this.validateID();
            }

        }

        private void staffID_Load(object sender, EventArgs e)
        {
            this.txtFN.Focus();
            
        }
    }
}
