﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class jointViewBatchCode : Form
    {
        public jointViewBatchCode()
        {
            InitializeComponent();
        }

        private void jointViewBatchCode_Load(object sender, EventArgs e)
        {
            this.displayRecord();
        }
        private DataTable GetData(string sql)
        {
            string constr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(sql))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        cmd.Connection = con;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        private void displayRecord()
        {
            //string sql = "SELECT TOP 10 c.CustomerId, c.ContactName, o.OrderId,";
            //sql += " (e.FirstName + ' ' + e.LastName) EmployeeName";
            //sql += " FROM Customers c INNER JOIN Orders o on c.CustomerId = o.CustomerId";
            //sql += " INNER JOIN Employees e ON e.EmployeeId = o.EmployeeId";
            string sql = "SELECT s.SN, s.FULL_NAME, s.CATEGOREY, s.STUDENT_UNIQUE_ID, c.classTime, c.batchCode";
            //sql += " (e.FirstName + ' ' + e.LastName) EmployeeName";
            sql += " FROM tbl_StudentID_Info s INNER JOIN tbl_student_BatchCode c on s.SN = c.SN";
            //sql += " INNER JOIN Employees e ON e.EmployeeId = o.EmployeeId";
            dGridViewCodes.DataSource = this.GetData(sql);
           // dGridViewCodes.DataBind();
        }
    }
}
