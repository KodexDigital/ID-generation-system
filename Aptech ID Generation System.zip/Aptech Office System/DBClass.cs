﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Threading.Tasks;

namespace Aptech_Office_System
{
    public class DBConnctionQuery
    {
        public SqlConnection con;
        public SqlCommand cmd;

        public void Connect()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBConnection "].ConnectionString);
            con.Open();
            cmd = new SqlCommand();
            cmd.Connection = con;
        }
    }
}
