﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;


namespace Aptech_Office_System
{
    public partial class viewBatchCode : Form
    {
        public viewBatchCode()
        {
            InitializeComponent();
        }

        private void viewBatchCode_Load(object sender, EventArgs e)
        {
            this.Code_View();
        }
        private void Code_View()
        {
            string View;
            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT [studentID],[uniqueCode] FROM tbl_student_BatchCode ORDER BY uniqueCode DESC", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            View = dr["studentID"].ToString().ToString();
                            List<String> StudentIDList = new List<string>();
                            StudentIDList.Add(View);

                            foreach (string Reminder in StudentIDList)
                            {
                                lBoxCode.Items.Add(Reminder);
                                lBoxCode.Refresh();
                            }
                        }
                        con.Close();
                    }
                }
            }
        }

        private void view_BatchCode()
        {
            // string View;
            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT [studentID],[batchCode] FROM tbl_student_BatchCode WHERE studentID ='" + lBoxCode.SelectedItem.ToString() + "' ", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            lblShowID.Text = dr["batchCode"].ToString();
                        }
                        con.Close();
                    }
                }
            }
        }

        private void lBoxCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lBoxCode.SelectedItem == null)
            {
                MessageBox.Show("Nothing is selected yet!", "Information...");
            }
            else
            {
                this.view_BatchCode();
            }
        }
    }
}
