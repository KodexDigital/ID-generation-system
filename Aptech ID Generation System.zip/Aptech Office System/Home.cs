﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aptech_Office_System
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            lblDate.Text = "Welcome".ToUpper() + ", " + "Today is: " + System.DateTime.Today.ToShortDateString();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            bool buttonClicked = true;
            if (buttonClicked == true)
            {
                
                if (MessageBox.Show("Are You Sure You Want To Logout?", "Loging Out....", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    Application.Exit();
                }
             }
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            bool buttonCliked = true;
                if (buttonCliked == true)
                {
                createUser NewUser = new createUser();
                NewUser.ShowDialog();
                }
        }

        private void btnNewCategory_Click(object sender, EventArgs e)
        {
            bool buttonCliked = true;
            if (buttonCliked == true)
            {
                StudentCatAdd NewCategory = new StudentCatAdd();
                NewCategory.ShowDialog();
            }
        }

        private void btnGenerateStaffID_Click(object sender, EventArgs e)
        {
            bool buttonCliked = true;
            if (buttonCliked == true)
            {
                staffID IDStaff = new staffID();
                IDStaff.ShowDialog();
            }
        }

        private void btnGenerateStudentID_Click(object sender, EventArgs e)
        {
            bool buttonCliked = true;
            if (buttonCliked == true)
            {
                studentID IDStudent = new studentID();
                IDStudent.ShowDialog();
            }
        }
        private void btnExitApp_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Leaving The Home Page?", "Leaving...", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                loginUser NewLogin = new loginUser();
                NewLogin.Show();
                this.Hide();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("This function is currently under contruction right now. Comming Soon...", "Updating..." + "\r\n" + "Thank You For Your Understanding");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            viewIDStaff NewStaffIDPage = new viewIDStaff();
            NewStaffIDPage.ShowDialog();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            viewStudentID NewStudentIDPage = new viewStudentID();
            NewStudentIDPage.ShowDialog();
        }

        private void btnBatchCode_Click(object sender, EventArgs e)
        {
            studentBatchCode newBatchCode = new studentBatchCode();
            newBatchCode.ShowDialog();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            viewBatchCode newViewCode = new viewBatchCode();
            newViewCode.ShowDialog();
        }
    }
}
