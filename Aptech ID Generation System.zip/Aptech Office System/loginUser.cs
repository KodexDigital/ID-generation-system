﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class loginUser : Form
    {
        public static string userName, passWord;
        public loginUser()
        {
            InitializeComponent();
        }

        private void loginUser_Load(object sender, EventArgs e)
        {
            this.txtUserLog.Focus();
            this.txtPassLog.Text = "";
            this.txtUserLog.Text = "";
        }

        public void Login()
        {
            userName = this.txtUserLog.Text.ToString();
            passWord = this.txtPassLog.Text.ToString();

            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT [USERNAME],[PASSWORD] FROM tbl_UserLog_Info WHERE USERNAME= '" + userName.ToString() + "' AND PASSWORD ='" + passWord.ToString() + "' ", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.Read())
                        {
                            this.txtUserLog.Clear();
                            this.txtPassLog.Clear();
                            lblErr.Text = "";

                            Home OpenHome = new Home();
                            OpenHome.Show();
                            this.Hide();
                        }
                        else
                        {
                            lblErr.Text = "Ops! Access Denied - Something is Missing...";
                        }


                        con.Close();
                    }
                }
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Login();
        }

        private void lnklblNewUser_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            createUser NewUser = new createUser();
            NewUser.ShowDialog();
            //this.Dispose();
        }

        private void btnExitApp_Click(object sender, EventArgs e)
        {
            bool buttonCliked = true;
            if (buttonCliked == true)
            {
                if (MessageBox.Show("Exiting System?", "Exiting...", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Application.Exit();
                }
            }
        }
    }
}
