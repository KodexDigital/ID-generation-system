﻿namespace Aptech_Office_System
{
    partial class studentBatchCode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(studentBatchCode));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.gBoxGetInfo = new System.Windows.Forms.GroupBox();
            this.txtDOA = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnContinue = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gBoxVerify = new System.Windows.Forms.GroupBox();
            this.btnVerify = new System.Windows.Forms.Button();
            this.lblErrCode_Verify = new System.Windows.Forms.Label();
            this.txtStudentID_Verify = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.gBoxCode = new System.Windows.Forms.GroupBox();
            this.lblShowCode = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pixError = new System.Windows.Forms.PictureBox();
            this.chk_4 = new System.Windows.Forms.CheckBox();
            this.chk_2 = new System.Windows.Forms.CheckBox();
            this.chk_11 = new System.Windows.Forms.CheckBox();
            this.chk_9 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblErrDescript = new System.Windows.Forms.Label();
            this.lblErrCode = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.pBarVerify = new System.Windows.Forms.ProgressBar();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.gBoxGetInfo.SuspendLayout();
            this.gBoxVerify.SuspendLayout();
            this.gBoxCode.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pixError)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.gBoxGetInfo);
            this.panel1.Controls.Add(this.gBoxVerify);
            this.panel1.Controls.Add(this.gBoxCode);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1035, 494);
            this.panel1.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label5.Font = new System.Drawing.Font("Bell MT", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(-2, 469);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(1039, 23);
            this.label5.TabIndex = 27;
            this.label5.Text = "All Right Reserved - 2018 [Produced By Digital]";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Aptech_Office_System.Properties.Resources.Aptech_Logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(1, 58);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1036, 4);
            this.panel3.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("OCR-A BT", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(317, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(373, 35);
            this.label9.TabIndex = 24;
            this.label9.Text = "BATCH CODE SECTION";
            // 
            // gBoxGetInfo
            // 
            this.gBoxGetInfo.Controls.Add(this.txtDOA);
            this.gBoxGetInfo.Controls.Add(this.label4);
            this.gBoxGetInfo.Controls.Add(this.txtCate);
            this.gBoxGetInfo.Controls.Add(this.label3);
            this.gBoxGetInfo.Controls.Add(this.btnContinue);
            this.gBoxGetInfo.Controls.Add(this.txtName);
            this.gBoxGetInfo.Controls.Add(this.label6);
            this.gBoxGetInfo.Font = new System.Drawing.Font("Tahoma", 12F);
            this.gBoxGetInfo.Location = new System.Drawing.Point(146, 213);
            this.gBoxGetInfo.Name = "gBoxGetInfo";
            this.gBoxGetInfo.Size = new System.Drawing.Size(392, 225);
            this.gBoxGetInfo.TabIndex = 23;
            this.gBoxGetInfo.TabStop = false;
            // 
            // txtDOA
            // 
            this.txtDOA.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDOA.Font = new System.Drawing.Font("Tahoma", 10F);
            this.txtDOA.Location = new System.Drawing.Point(6, 154);
            this.txtDOA.Name = "txtDOA";
            this.txtDOA.ReadOnly = true;
            this.txtDOA.Size = new System.Drawing.Size(295, 24);
            this.txtDOA.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 19);
            this.label4.TabIndex = 19;
            this.label4.Text = "Admission Date";
            // 
            // txtCate
            // 
            this.txtCate.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCate.Font = new System.Drawing.Font("Tahoma", 10F);
            this.txtCate.Location = new System.Drawing.Point(6, 101);
            this.txtCate.Name = "txtCate";
            this.txtCate.ReadOnly = true;
            this.txtCate.Size = new System.Drawing.Size(295, 24);
            this.txtCate.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 19);
            this.label3.TabIndex = 17;
            this.label3.Text = "Category";
            // 
            // btnContinue
            // 
            this.btnContinue.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnContinue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnContinue.Enabled = false;
            this.btnContinue.ForeColor = System.Drawing.Color.White;
            this.btnContinue.Location = new System.Drawing.Point(6, 183);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(295, 38);
            this.btnContinue.TabIndex = 16;
            this.btnContinue.Text = "Continue";
            this.btnContinue.UseVisualStyleBackColor = false;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // txtName
            // 
            this.txtName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtName.Font = new System.Drawing.Font("Tahoma", 10F);
            this.txtName.ForeColor = System.Drawing.Color.Red;
            this.txtName.Location = new System.Drawing.Point(6, 49);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(295, 24);
            this.txtName.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(2, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 19);
            this.label6.TabIndex = 13;
            this.label6.Text = "Student\'s Name";
            // 
            // gBoxVerify
            // 
            this.gBoxVerify.Controls.Add(this.pBarVerify);
            this.gBoxVerify.Controls.Add(this.btnVerify);
            this.gBoxVerify.Controls.Add(this.lblErrCode_Verify);
            this.gBoxVerify.Controls.Add(this.txtStudentID_Verify);
            this.gBoxVerify.Controls.Add(this.label8);
            this.gBoxVerify.Font = new System.Drawing.Font("Tahoma", 12F);
            this.gBoxVerify.Location = new System.Drawing.Point(146, 102);
            this.gBoxVerify.Name = "gBoxVerify";
            this.gBoxVerify.Size = new System.Drawing.Size(392, 105);
            this.gBoxVerify.TabIndex = 22;
            this.gBoxVerify.TabStop = false;
            this.gBoxVerify.Text = "Student ID Verification";
            // 
            // btnVerify
            // 
            this.btnVerify.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerify.Location = new System.Drawing.Point(300, 49);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.Size = new System.Drawing.Size(83, 27);
            this.btnVerify.TabIndex = 16;
            this.btnVerify.Text = "Verify\r\n";
            this.btnVerify.UseVisualStyleBackColor = true;
            this.btnVerify.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // lblErrCode_Verify
            // 
            this.lblErrCode_Verify.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrCode_Verify.ForeColor = System.Drawing.Color.DarkRed;
            this.lblErrCode_Verify.Location = new System.Drawing.Point(6, 77);
            this.lblErrCode_Verify.Name = "lblErrCode_Verify";
            this.lblErrCode_Verify.Size = new System.Drawing.Size(279, 24);
            this.lblErrCode_Verify.TabIndex = 15;
            this.lblErrCode_Verify.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // txtStudentID_Verify
            // 
            this.txtStudentID_Verify.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtStudentID_Verify.Location = new System.Drawing.Point(6, 49);
            this.txtStudentID_Verify.Name = "txtStudentID_Verify";
            this.txtStudentID_Verify.Size = new System.Drawing.Size(295, 27);
            this.txtStudentID_Verify.TabIndex = 14;
            this.txtStudentID_Verify.TextChanged += new System.EventHandler(this.txtStudentID_Verify_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(2, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 19);
            this.label8.TabIndex = 13;
            this.label8.Text = "Enter Student\'s ID";
            // 
            // gBoxCode
            // 
            this.gBoxCode.Controls.Add(this.lblShowCode);
            this.gBoxCode.Controls.Add(this.panel2);
            this.gBoxCode.Controls.Add(this.lblErrDescript);
            this.gBoxCode.Controls.Add(this.lblErrCode);
            this.gBoxCode.Controls.Add(this.btnClose);
            this.gBoxCode.Controls.Add(this.btnNew);
            this.gBoxCode.Controls.Add(this.btnSave);
            this.gBoxCode.Controls.Add(this.txtStudentID);
            this.gBoxCode.Controls.Add(this.label1);
            this.gBoxCode.Enabled = false;
            this.gBoxCode.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gBoxCode.Location = new System.Drawing.Point(601, 120);
            this.gBoxCode.Name = "gBoxCode";
            this.gBoxCode.Size = new System.Drawing.Size(273, 298);
            this.gBoxCode.TabIndex = 21;
            this.gBoxCode.TabStop = false;
            this.gBoxCode.Text = "New Batch Code";
            // 
            // lblShowCode
            // 
            this.lblShowCode.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lblShowCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShowCode.Font = new System.Drawing.Font("Tahoma", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShowCode.ForeColor = System.Drawing.Color.Green;
            this.lblShowCode.Location = new System.Drawing.Point(7, 257);
            this.lblShowCode.Name = "lblShowCode";
            this.lblShowCode.Size = new System.Drawing.Size(257, 38);
            this.lblShowCode.TabIndex = 15;
            this.lblShowCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pixError);
            this.panel2.Controls.Add(this.chk_4);
            this.panel2.Controls.Add(this.chk_2);
            this.panel2.Controls.Add(this.chk_11);
            this.panel2.Controls.Add(this.chk_9);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(7, 82);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(260, 135);
            this.panel2.TabIndex = 13;
            // 
            // pixError
            // 
            this.pixError.Image = global::Aptech_Office_System.Properties.Resources.Wrong;
            this.pixError.Location = new System.Drawing.Point(168, 44);
            this.pixError.Name = "pixError";
            this.pixError.Size = new System.Drawing.Size(82, 90);
            this.pixError.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pixError.TabIndex = 4;
            this.pixError.TabStop = false;
            this.pixError.Visible = false;
            // 
            // chk_4
            // 
            this.chk_4.AutoSize = true;
            this.chk_4.Location = new System.Drawing.Point(3, 109);
            this.chk_4.Name = "chk_4";
            this.chk_4.Size = new System.Drawing.Size(132, 23);
            this.chk_4.TabIndex = 3;
            this.chk_4.Text = "4pm - 6:30pm";
            this.chk_4.UseVisualStyleBackColor = true;
            this.chk_4.CheckedChanged += new System.EventHandler(this.chk_4_CheckedChanged);
            // 
            // chk_2
            // 
            this.chk_2.AutoSize = true;
            this.chk_2.Location = new System.Drawing.Point(3, 82);
            this.chk_2.Name = "chk_2";
            this.chk_2.Size = new System.Drawing.Size(108, 23);
            this.chk_2.TabIndex = 2;
            this.chk_2.Text = "2pm - 4pm";
            this.chk_2.UseVisualStyleBackColor = true;
            this.chk_2.CheckedChanged += new System.EventHandler(this.chk_2_CheckedChanged_1);
            // 
            // chk_11
            // 
            this.chk_11.AutoSize = true;
            this.chk_11.Location = new System.Drawing.Point(3, 54);
            this.chk_11.Name = "chk_11";
            this.chk_11.Size = new System.Drawing.Size(116, 23);
            this.chk_11.TabIndex = 1;
            this.chk_11.Text = "11am - 1pm";
            this.chk_11.UseVisualStyleBackColor = true;
            this.chk_11.CheckedChanged += new System.EventHandler(this.chk_11_CheckedChanged_1);
            // 
            // chk_9
            // 
            this.chk_9.AutoSize = true;
            this.chk_9.Location = new System.Drawing.Point(4, 27);
            this.chk_9.Name = "chk_9";
            this.chk_9.Size = new System.Drawing.Size(115, 23);
            this.chk_9.TabIndex = 0;
            this.chk_9.Text = "9am - 11am";
            this.chk_9.UseVisualStyleBackColor = true;
            this.chk_9.CheckedChanged += new System.EventHandler(this.chk_9_CheckedChanged_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select Student\'s Class Time";
            // 
            // lblErrDescript
            // 
            this.lblErrDescript.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrDescript.ForeColor = System.Drawing.Color.DarkRed;
            this.lblErrDescript.Location = new System.Drawing.Point(92, 108);
            this.lblErrDescript.Name = "lblErrDescript";
            this.lblErrDescript.Size = new System.Drawing.Size(175, 24);
            this.lblErrDescript.TabIndex = 12;
            this.lblErrDescript.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblErrCode
            // 
            this.lblErrCode.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrCode.ForeColor = System.Drawing.Color.DarkRed;
            this.lblErrCode.Location = new System.Drawing.Point(107, 27);
            this.lblErrCode.Name = "lblErrCode";
            this.lblErrCode.Size = new System.Drawing.Size(160, 24);
            this.lblErrCode.TabIndex = 12;
            this.lblErrCode.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(208, 216);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(56, 41);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnNew
            // 
            this.btnNew.Location = new System.Drawing.Point(127, 216);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(82, 41);
            this.btnNew.TabIndex = 7;
            this.btnNew.Text = "New";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click_1);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(7, 216);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(122, 41);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtStudentID
            // 
            this.txtStudentID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtStudentID.Location = new System.Drawing.Point(10, 53);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.ReadOnly = true;
            this.txtStudentID.Size = new System.Drawing.Size(257, 27);
            this.txtStudentID.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student\'s ID";
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ShowAlways = true;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Verify ID...";
            this.toolTip1.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip1_Popup);
            // 
            // pBarVerify
            // 
            this.pBarVerify.Location = new System.Drawing.Point(300, 80);
            this.pBarVerify.Maximum = 50;
            this.pBarVerify.Name = "pBarVerify";
            this.pBarVerify.Size = new System.Drawing.Size(91, 23);
            this.pBarVerify.Step = 20;
            this.pBarVerify.TabIndex = 28;
            this.pBarVerify.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(3, 475);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Version: 1.1.0";
            // 
            // studentBatchCode
            // 
            this.AcceptButton = this.btnVerify;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1035, 494);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "studentBatchCode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aptech ID Generation System: Batch Code";
            this.Load += new System.EventHandler(this.studentBatchCode_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.gBoxGetInfo.ResumeLayout(false);
            this.gBoxGetInfo.PerformLayout();
            this.gBoxVerify.ResumeLayout(false);
            this.gBoxVerify.PerformLayout();
            this.gBoxCode.ResumeLayout(false);
            this.gBoxCode.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pixError)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gBoxGetInfo;
        private System.Windows.Forms.TextBox txtDOA;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox gBoxVerify;
        private System.Windows.Forms.Button btnVerify;
        private System.Windows.Forms.Label lblErrCode_Verify;
        private System.Windows.Forms.TextBox txtStudentID_Verify;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox gBoxCode;
        private System.Windows.Forms.Label lblShowCode;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pixError;
        private System.Windows.Forms.CheckBox chk_4;
        private System.Windows.Forms.CheckBox chk_2;
        private System.Windows.Forms.CheckBox chk_11;
        private System.Windows.Forms.CheckBox chk_9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblErrDescript;
        private System.Windows.Forms.Label lblErrCode;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ProgressBar pBarVerify;
        private System.Windows.Forms.Label label7;

    }
}