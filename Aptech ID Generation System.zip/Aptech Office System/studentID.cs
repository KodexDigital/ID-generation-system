﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class studentID : Form
    {
        private string fullName, category, dateAdmittted;
        private string dateOfAdmission, staffUniqueID;
        private string userOn, dateOfCreation;

        private string company, uniqueValue, firstID;
        private int uniqueNo, cntID, newID;
        private string getID;

        public studentID()
        {
            InitializeComponent();
            cntID = 1;
            newID = 0;

        }

        private void studentID_Load(object sender, EventArgs e)
        {
            this.txtFN.Focus();

            this.LoadCourseCategory();
        }

        private void LoadCourseCategory()
        { 
            string constr = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
            using (SqlCommand cmd = new SqlCommand("SELECT [CATEGORY] FROM [tbl_CourseCategory]", con))
            {
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {

            DataTable dt = new DataTable();
            da.Fill(dt);

            DataRow dr = dt.NewRow();
            dr.ItemArray  = new object[] {"Select Category"};
            dt.Rows.InsertAt(dr, 0);

            this.cboxCategory.DisplayMember = "CATEGORY";
            //this.comboBox1.ValueMember = "SN";
            this.cboxCategory.DataSource = dt;
            }
            }
            }
        }
        private void validateID()
        {

            //select the records from the recieval table here
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT MAX (UNIQUE_ID) AS max_UniqueID FROM tbl_StudentID_Info", con))
                    //("SELECT TOP (1) [UNIQUE_ID] FROM tbl_StaffID_Info WHERE UNIQUE_ID = 0 OR Status = 1 ORDER BY UNIQUE_ID DESC'", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == true)
                        {
                            dr.Read();
                            getID = dr["max_UniqueID"].ToString();

                            if (getID == string.Empty)
                            {
                                firstID = "null";
                                if (firstID == "null")  // this section is to check if ID exist for the first time
                                {
                                    //newID += cntID;
                                    this.generateStaffID_NewEmpty();
                                    // MessageBox.Show(newID.ToString("000"));

                                }
                            }
                            else if (getID != string.Empty)  //Here is for the generation and insertion  this section is to check if ID always
                            {
                                //firstID = getID.ToString();
                                //uniqueNo = int.Parse(firstID) + cntID;
                                this.generateStaffID_Existing();
                                //MessageBox.Show(uniqueNo.ToString("000"));
                            }
                        }
                        else
                        {
                            //MessageBox.Show("NO ID Yet!");
                            //lblConnect.Visible = true;
                            //lblConnect.Text = "Access Rejected - Something is Missing...";
                        }


                        con.Close();
                    }
                }
            }
        }
        public void generateStaffID_NewEmpty()
        {
            if (this.txtFN.Text == "") { MessageBox.Show("Please Enter The Students Full Name. And Try Again..." + "\r\n" + "Thank You!", "Validating ID..."); }
            else if (cboxCategory.Text == "Select Category")
            { MessageBox.Show("Student's Course Category Not Properly Selected!" + "\r\n" + "Please Correct This And Continue... " + " Thank You!", "Validating ID..."); }
            else if (cboxMonth.Text == "Select Month" || cboxYear.Text == "Select Year")
            { MessageBox.Show("Admission Date Not Properly Selected!" + "\r\n" + "Please Correct This And Continue... " + " Thank You!", "Validating ID..."); }
            else
            {
                company = "apt".ToUpper();
                dateOfAdmission = this.cboxCategory.Text.ToString() + "/" + this.cboxMonth.SelectedItem.ToString() + cboxYear.SelectedItem.ToString();
                //uniqueNo = 1;
                newID += cntID;
                uniqueValue = newID.ToString("000");
                staffUniqueID = company + "/" + dateOfAdmission + uniqueValue;
                MessageBox.Show("STUDENT UNIQUE ID GENERATED SUCCESSFULLY!" + "\r\n" + "Please Copy It Out, Then Save it by clicking the 'Save Button'", "ID Generating...");
                lblShowID.Text = staffUniqueID.ToString();

                this.btnSave.Enabled = true;
            }
            //else 
        }
        public void generateStaffID_Existing()
        {
            if (this.txtFN.Text == "") { MessageBox.Show("Please Enter The Students Full Name. And Try Again..." + "\r\n" + "Thank You!", "Validating ID..."); }
            else if (cboxCategory.Text == "Select Category")
            { MessageBox.Show("Student's Course Category Not Properly Selected!" + "\r\n" + "Please Correct This And Continue... " + " Thank You!", "Validating ID..."); }
            else if (cboxMonth.Text == "Select Month" || cboxYear.Text == "Select Year")
            { MessageBox.Show("Admission Date Not Properly Selected!" + "\r\n" + "Please Correct This And Continue... " + " Thank You!", "Validating ID..."); }
            else
            {
                company = "apt".ToUpper();
                dateOfAdmission = this.cboxCategory.Text.ToString() + "/" + this.cboxMonth.SelectedItem.ToString() + cboxYear.SelectedItem.ToString();
                //uniqueNo = 1;
                firstID = getID.ToString();
                uniqueNo = int.Parse(firstID) + cntID;
                uniqueValue = uniqueNo.ToString("000");
                staffUniqueID = company + "/" + dateOfAdmission + uniqueValue;
                MessageBox.Show("STUDENT UNIQUE ID GENERATED SUCCESSFULLY!" + "\r\n" + "Please Copy It Out, Then Save it by clicking the 'Save Button'", "ID Generating...");
                lblShowID.Text = staffUniqueID.ToString();

                this.btnSave.Enabled = true;
            }
            //else 
        }
        private void Save_ID()
        {
            if (this.txtFN.Text == string.Empty) { MessageBox.Show("Required: Student's Full Name" + "\r\n" + "Please Enter The Student's Full Name", "Required Field..."); this.txtFN.Focus(); }
            else
            {
                fullName = this.txtFN.Text.ToString();
                category = this.cboxCategory.Text.ToString();
                dateAdmittted = this.cboxMonth.Text.ToString() + cboxYear.Text.ToString();
                dateOfCreation = System.DateTime.Now.ToShortDateString();
                userOn = loginUser.userName.ToString();

                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_StudentID_Info (FULL_NAME, CATEGOREY, DOA, createdBy, createdDate, UNIQUE_ID, STUDENT_UNIQUE_ID) VALUES (@FULL_NAME, @CATEGOREY, @DOA, @createdBy, @createdDate, @UNIQUE_ID, @STUDENT_UNIQUE_ID)", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@FULL_NAME", fullName.Trim());
                        cmd.Parameters.AddWithValue("@CATEGOREY", category.Trim());
                        cmd.Parameters.AddWithValue("@DOA", dateAdmittted.Trim());
                        cmd.Parameters.AddWithValue("@createdBy", userOn.Trim());
                        cmd.Parameters.AddWithValue("@createdDate", dateOfCreation.Trim());
                        cmd.Parameters.AddWithValue("@UNIQUE_ID", uniqueValue.Trim());
                        cmd.Parameters.AddWithValue("@STUDENT_UNIQUE_ID", staffUniqueID.Trim());
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        MessageBox.Show("STUDENT'S UNIQUE ID SAVED SUCCESSFULLY!");
                        this.txtFN.Clear();
                        this.cboxCategory.Text = "Select Category".ToString();
                        this.cboxMonth.Text = "Select Month".ToString();
                        this.cboxYear.Text = "Select Year".ToString();
                        this.lblShowID.Text = string.Empty;
                        con.Close();

                    }
                }
            }


        }

        private void btnGenerate_Click(object sender, System.EventArgs e)
        {
            bool buttonClicked = true;
            if (buttonClicked == true)
            {
                this.validateID();
            }
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            this.Save_ID();
        }
    }
}
