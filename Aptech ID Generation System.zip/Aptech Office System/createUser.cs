﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Aptech_Office_System
{
    public partial class createUser : Form
    {
        private string userName, passWord, pKey, dateCreated;
        public createUser()
        {
            InitializeComponent();
        }

        private void createUser_Load(object sender, EventArgs e)
        {
            this.txtUser.Focus();
        }
        public void validateUser_Save()
        {
            userName = this.txtUser.Text.ToString();
            passWord = this.txtpass.Text.ToString();
            pKey = this.txtKey.Text.ToString();

            //select the records from the recieval table here
            if (this.txtKey.Text == "") 
            {
                this.lblErrKey.Text = "Permission Key Required!";
            }
            else 
            { 
            {
                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT * FROM tbl_UserLog_Info WHERE PERMISSION_KEY= '" + pKey.ToString() + "' ", con))
                    //("SELECT TOP (1) [UNIQUE_ID] FROM tbl_StaffID_Info WHERE UNIQUE_ID = 0 OR Status = 1 ORDER BY UNIQUE_ID DESC'", con))
                    //("SELECT MAX (patient_id) as max_patient_id FROM patient_data ", cnz);
                    {
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == true)
                        {
                            //Save New User Info
                            this.SaveInfo();
                            //this.UpdateSave_Info();
                        }
                        else
                        {
                            lblErrKey.Text = "Invlaid Permission Key!";
                            this.txtKey.Clear();
                            this.txtKey.Focus();
                        }


                        con.Close();
                    }
                }
            }
        }
        }
        public void SaveInfo()
        {
            {
                userName = this.txtUser.Text.ToString();
                passWord = this.txtpass.Text.ToString();
                pKey = "Null";
                dateCreated = System.DateTime.Now.ToShortDateString();

                string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constring))
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_UserLog_Info (USERNAME, PASSWORD, PERMISSION_KEY, createdDate) VALUES (@USERNAME, @PASSWORD, @PERMISSION_KEY, @createdDate)", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@USERNAME", userName.Trim());
                        cmd.Parameters.AddWithValue("@PASSWORD", passWord.Trim());
                        cmd.Parameters.AddWithValue("@PERMISSION_KEY", pKey.Trim());
                        cmd.Parameters.AddWithValue("@createdDate", dateCreated.Trim());
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        MessageBox.Show("NEW USER CREATED AND SAVED SUCCESSFULLY!");
                        this.txtUser.Clear();
                        this.txtpass.Clear();
                        this.txtKey.Clear();
                        this.lblErrKey.Text = "";
                        this.lblErrUser.Text = "";
                        this.lblErrPass.Text = "";
                        con.Close();

                    }
                }
            }
        }

        private void UpdateSave_Info()
        {

            string constring = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constring))
            {
                //updating the status ("SELECT * FROM tbl_UserLog_Info WHERE PERMISSION_KEY= '" + pKey.ToString() + "' ", con))
                using (SqlCommand cmd = new SqlCommand("UPDATE tbl_UserLog_Info SET USERNAME = '" + userName.ToString() + "' AND PASSWORD ='" + passWord.ToString() + "' AND createdDate ='" + dateCreated.ToString() + "' ", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@USERNAME", userName);
                    cmd.Parameters.AddWithValue("@PASSWORD", passWord);
                    cmd.Parameters.AddWithValue("@createdDate", dateCreated);
                    // cmd.Parameters.AddWithValue("@City", city); USERNAME, PASSWORD, createdDate
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show("NEW USER CREATED AND SAVED SUCCESSFULLY!");
                    this.txtUser.Clear();
                    this.txtpass.Clear();
                    this.txtKey.Clear();
                    this.lblErrKey.Text = "";
                    this.lblErrUser.Text = "";
                    this.lblErrPass.Text = "";
                    con.Close();
                }

               }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtUser.Text == "") { this.lblErrUser.Text = "Username Required!"; txtUser.Focus(); }
            else if (txtpass.Text == "") { this.lblErrPass.Text = "Password Required!"; txtpass.Focus(); }
            else { this.validateUser_Save(); }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.txtUser.Clear();
            this.txtpass.Clear();
            this.txtKey.Clear();
            this.lblErrKey.Text = "";
            this.lblErrUser.Text = "";
            this.lblErrPass.Text = "";
            this.txtUser.Focus();
        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {
            if (this.txtUser.Text != "") { this.lblErrUser.Text = ""; }
        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {
            if (this.txtpass.Text != "") { this.lblErrPass.Text = ""; }
        }

        private void txtKey_TextChanged(object sender, EventArgs e)
        {
            if (this.txtKey.Text != "") { this.lblErrKey.Text = ""; }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            bool buttonClicked = true;
            if (buttonClicked == true)
            {
                this.Hide();
            }
        }
    }
}
